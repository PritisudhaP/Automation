#! /usr/local/bin/python3


from pymongo import MongoClient
import sys



# Mongo connection details
#MONGO_HOST = sys.argv[1]
#MONGO_PORT = int(sys.argv[2])

MONGO_CONN_STRING = "mongodb://pssc:pssc@qa36-shard-00-00-fpaqn.mongodb.net:27017,qa36-shard-00-01-fpaqn.mongodb.net:27017,qa36-shard-00-02-fpaqn.mongodb.net:27017/app-orr165?replicaSet=QA36-shard-0&authSource=admin&ssl=true"

project = sys.argv[1]
version = sys.argv[2]

mongoclient = MongoClient(MONGO_CONN_STRING)

if project == 'SCL':
    dataDomain = "com.scl"
    MONGO_DB = "app-scl" + version.replace(".","")
    mongodb = mongoclient[MONGO_DB]


    mongodb['product'].remove({"refName":"automationproduct1"})
    mongodb['salesOrder'].remove({"header.orderNumber":"Automation001"})

elif project == 'FLEETPRIDE':
    dataDomain = "com.fleetpride"
    MONGO_DB = "app-fleetpride" + version.replace(".","")
    mongodb = mongoclient[MONGO_DB]
    mongodb['product'].remove({"refName":"PritiAutomation01"})
    mongodb['product'].remove({"refName":"PritiAutomation02"})
    mongodb['product'].remove({"refName":"PritiKit01"})
    mongodb['product'].remove({"refName":"Priti-Kit02"})
    mongodb['sku'].remove({"refName":"PritiKit01"})
    mongodb['sku'].remove({"refName":"Priti-Kit02"})
    mongodb['sku'].remove({"refName":"PritiAutomation01"})
    mongodb['sku'].remove({"refName":"PritiAutomation02"})

print(MONGO_DB)

mongoclient.close()
